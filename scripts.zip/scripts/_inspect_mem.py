import json

with open('.claude/memories/project_memory.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

print('top-level keys:', list(data.keys()))
rm = data.get('realtime_memories', [])
print('count:', len(rm))
if rm:
    print('sample entry keys:', list(rm[0].keys()) if isinstance(rm[0], dict) else type(rm[0]))
    print(json.dumps(rm[0], indent=2)[:1000])
