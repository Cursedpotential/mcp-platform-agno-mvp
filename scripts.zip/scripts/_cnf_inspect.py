import json

path = r"E:/AI_Workspace/Projects/the-platform-workspace/Agno-MCP-Platform/.claude/memories/project_memory.json"
with open(path, encoding="utf-8") as f:
    d = json.load(f)

print("KEYS:", list(d.keys()))
rm = d.get("realtime_memories", [])
print("REALTIME COUNT:", len(rm))
print("MANUAL COUNT:", len(d.get("manual_memories", [])))
print("=== ENTRIES ===")
for i, m in enumerate(rm):
    if isinstance(m, dict):
        t = m.get("type", "")
        ts = m.get("timestamp", m.get("time", m.get("date", "")))
        # collect a short preview of the content
        preview = ""
        for k in ("content", "message", "text", "summary", "value", "event"):
            if k in m and isinstance(m[k], str):
                preview = m[k]
                break
        print(f"--- [{i}] type={t} ts={ts}")
        print(str(preview)[:300].replace("\n", " "))
    else:
        print(f"--- [{i}] (non-dict) {str(m)[:200]}")